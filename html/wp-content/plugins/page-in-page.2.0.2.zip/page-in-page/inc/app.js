/**
 * 
 * Hook in plugin JS
 */