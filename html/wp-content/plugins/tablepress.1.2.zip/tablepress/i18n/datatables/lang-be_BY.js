{
	"sProcessing":	 "Пачакайце...",
	"sLengthMenu":	 "Паказаць _MENU_ запісаў",
	"sZeroRecords":	 "Запісы адсутнічаюць.",
	"sInfo":		 "Запісы з _START_ да _END_ з _TOTAL_ запісаў",
	"sInfoEmpty":	 "Запісы з 0 да 0 з 0 запісаў",
	"sInfoFiltered": "(адфільтравана з _MAX_ запісаў)",
	"sInfoPostFix":	 "",
	"sSearch":		 "Пошук:",
	"oPaginate": {
		"sFirst": "Першая",
		"sPrevious": "Папярэдняя",
		"sNext": "Наступная",
		"sLast": "Апошняя"
	}
}